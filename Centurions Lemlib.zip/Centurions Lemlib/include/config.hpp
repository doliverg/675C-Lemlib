#include "api.h"
using namespace pros;
extern pros::Motor intake;
extern pros::Motor convey;
extern pros::MotorGroup conveyer;
extern pros::Distance distance_sensor;
extern pros::Motor Arms;
extern pros::Optical optical_sensor;
extern pros::ADIDigitalOut MogoClampL;
extern pros::ADIDigitalOut StealerClampL;
extern pros::ADIDigitalOut StealerdeployL;
extern pros::ADIDigitalOut DoinkerL;
extern pros::ADIDigitalOut SorterL;
