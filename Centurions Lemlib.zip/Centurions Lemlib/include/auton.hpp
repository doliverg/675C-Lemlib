#include "api.h"
#include "lemlib/api.hpp" // IWYU pragma: keep
using namespace pros;

void redawp();
void blueawp();
void redrush();
void bluerush();
void redfull();
void bluefull();
void skills();
int isRingValidRedirectauton();
void redirectauton();

extern bool isRedTeam;